<?php
define('DB_SERVER','localhost');
define('DB_USER','iugofypr_iugofypr');
define('DB_PASS' ,'Y1!LE)cZO3TX');
define('DB_NAME', 'iugofypr_wb_iugofi');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }

?>

