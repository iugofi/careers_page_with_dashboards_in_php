-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2024 at 06:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loginsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4'),
(2, 'kunal123', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_application`
--

CREATE TABLE `candidate_application` (
  `id` int(11) NOT NULL,
  `applicant_name` varchar(255) NOT NULL,
  `applicant_email` varchar(255) NOT NULL,
  `applicant_phone` varchar(20) NOT NULL,
  `applicant_letter` text NOT NULL,
  `job_id` int(11) NOT NULL,
  `cv_resume_path` varchar(255) NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `candidate_application`
--

INSERT INTO `candidate_application` (`id`, `applicant_name`, `applicant_email`, `applicant_phone`, `applicant_letter`, `job_id`, `cv_resume_path`, `submission_date`) VALUES
(1, 'Kunal Verma', 'kv@gmail.com', '9165454247', 'DEVELOPER', 22, 'uploads/m Resume.pdf', '2024-01-17 11:12:53'),
(2, 'Sam Verma', 'sam@gmail.com', '9165454247', 'd', 22, 'uploads/m Resume.pdf', '2024-01-17 11:14:54'),
(3, 'Kunal Verma', 'k@gmail.com', '9165454247', '', 22, 'uploads/m Resume.pdf', '2024-01-17 11:17:45'),
(4, 'Kunal Verma', 'k@gmail.com', '9165454247', 'bvnm', 22, 'uploads/m Resume.pdf', '2024-01-17 11:17:55');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id_company` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `aboutme` varchar(255) DEFAULT NULL,
  `logo` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `active` int(11) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id_company`, `name`, `companyname`, `country`, `state`, `city`, `contactno`, `website`, `email`, `password`, `aboutme`, `logo`, `createdAt`, `active`) VALUES
(12, 'jone', 'Iugofi', 'India', 'Panjab', 'Mohali', '6058790458', 'www.iugofi.com', 'iugofi@gmail.com', 'NTQ4MTg0NThlOTQ2YjY5NzA1MDg5YmI3YWUwZjlhMzY=', 'Just iugofi It', '268.jpg', '2024-01-19 16:12:00', 1),
(19, 'admintest', 'ganpact', 'india', 'odisha', 'bhuneswar', '7985675856', 'www.genpact.com', 'genpact@gmail.com', '', 'nothing', 'iugofilogo.png', '2024-01-17 18:30:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cusers`
--

CREATE TABLE `cusers` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `contactno` varchar(11) DEFAULT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cusers`
--

INSERT INTO `cusers` (`id`, `fname`, `lname`, `email`, `password`, `contactno`, `posting_date`) VALUES
(1, 'Rahul', 'Kumar', 'rahulj23@gmail.com', 'Test@123', '1234563210', '2023-12-12 06:15:52'),
(2, 'John', 'Doe', 'johndoe12@gamil.com', 'Test@12345', '4563210236', '2023-12-12 06:35:03');

-- --------------------------------------------------------

--
-- Table structure for table `job_post`
--

CREATE TABLE `job_post` (
  `id_jobpost` int(11) NOT NULL,
  `id_company` int(11) NOT NULL,
  `jobtitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `minimumsalary` varchar(255) NOT NULL,
  `maximumsalary` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `createdat` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `job_post`
--

INSERT INTO `job_post` (`id_jobpost`, `id_company`, `jobtitle`, `description`, `minimumsalary`, `maximumsalary`, `experience`, `qualification`, `createdat`) VALUES
(22, 12, 'Junior Developer', '                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <p>Write well designed, testable, efficient code by using best software development practices\r\nCreate website layout/user interface by using standard HTML/CSS practices\r\nIntegrate data from various back-end services and databases\r\nGather and refine specifications and requirements based on technical needs\r\nCreate and maintain software documentation\r\nBe responsible for maintaining, expanding, and scaling our site\r\nStay plugged into emerging technologies/industry trends and apply them into operations and activities\r\nCooperate with web designers to match visual design intent</p>\r\n<p> </p>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ', '5000', '50000', '1', 'BCA,B-TECH,MCA', '2017-10-03 09:28:43'),
(23, 12, 'Search Engine Optimization(S.E.O)', '<p>Your task is to develop new posibilities for the google search engine optimiztions, best working experience and priorities provide.:)</p>', '10000', '30000', '1', 'MCA', '2017-10-03 09:31:05'),
(24, 12, 'Content Writer', '                                                                                          Proven experience as a Content Writer, Copywriter, or similar role.\r\nBachelor’s degree in English, Journalism, or a related field.  \r\nMinimum of 2 years of experience in content writing and editing. \r\nFamiliarity with content management systems, such as WordPress, Drupal, or Joomla. \r\nSolid understanding of SEO principles and content optimization techniques. \r\nA strong portfolio showcasing published articles and writing styles. \r\nProficiency in MS Office. \r\nExcellent English writing and editing skills. \r\nOutstanding multi-tasking and communication skills.                                           \r\n                                                                                                                                    ', '', '', '2', 'BCA,B-TECH,MCA', '2024-01-19 04:38:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidate_application`
--
ALTER TABLE `candidate_application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id_company`);

--
-- Indexes for table `cusers`
--
ALTER TABLE `cusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_post`
--
ALTER TABLE `job_post`
  ADD PRIMARY KEY (`id_jobpost`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `candidate_application`
--
ALTER TABLE `candidate_application`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id_company` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `cusers`
--
ALTER TABLE `cusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_post`
--
ALTER TABLE `job_post`
  MODIFY `id_jobpost` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
