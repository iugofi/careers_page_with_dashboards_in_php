<?php $title = "Iugofi | Best Wifi Mesh System | Dual Band Wifi Router";
$description = "Best wifi mesh system network deals with Iugofi dual band wifi router with advanced features that enhance the reliability and flexibility of your business or home network.";
$keywords = "Iugoifi, Dual-band Wireless Router, Gigabit Ethernet Port Mesh Router, Gigabit Wired Connection, 11AC Dual Frequency Wireless USB Adapter, Mesh Wifi System, Gigabit Router, Gigabit Ethernet Port Mesh Router, Best Dual Band Router, Wireless Dual Band Gigabit Router, How to Use Dual Band Router, Mesh Wifi Extender, Wifi Range Extender, Iugofi Mesh Wifi System, Best Wifi Mesh System, Dual Band Router 5ghz, Dual Band Wifi Router, Gigabit Wifi Router";
include_once('front_header.php');
$countPostCategories = getPostCategoryCount($conn);
//echo $countPostCategories;
?>

<style>
.swiper-pagination {
    position: sticky;

}


</style>



   

<div class="wrapper">



        <div class="content-wrapper" style="margin-left: 0px;">

            <?php
  
    $sql = "SELECT * FROM job_post INNER JOIN company ON job_post.id_company=company.id_company WHERE id_jobpost='$_GET[id]'";
    $result = $conn->query($sql);
    if($result->num_rows > 0) 
    {
      while($row = $result->fetch_assoc()) 
      {
  ?>

            <section id="candidates" class="content-header" style="
    margin-top: 181px;
    margin-bottom: 129px;
">
                <div class="container">
                    <div class="row">
                        <div class="col-md-9 bg-white padding-2">
                            <div class="pull-left">
                                <h2><b><i><?php echo $row['jobtitle']; ?></i></b></h2>
                            </div>
                            <div class="pull-right">
                                <a href="career.php" class="btn btn-default btn-lg btn-flat margin-top-20"><i
                                        class="fa fa-arrow-circle-left"></i> Back</a>
                            </div>
                            <div class="clearfix"></div>
                            <hr>
                            <div>
                                <p><span class="margin-right-10"><i class="fa fa-location-arrow text-green"></i>
                                        <?php echo $row['city']; ?></span> <i class="fa fa-calendar text-green"></i>
                                    <?php echo date("d-M-Y", strtotime($row['createdat'])); ?></p>
                            </div>
                            <div>
                                <?php echo stripcslashes($row['description']); ?>
                            </div>
                            <?php 
            if(isset($_SESSION["id_user"]) && empty($_SESSION['companyLogged'])) { ?>
                            <div>
                                <a href="apply.php?id=<?php echo $row['id_jobpost']; ?>"
                                    class="btn btn-success btn-flat margin-top-50">Apply</a>
                            </div>
                            <?php } ?>


                        </div>
                        <div class="col-md-3">
                            <div class="thumbnail" style="border:1.5px solid #EB7341;padding:20px;box-shadow: 5px 5px 17px -10px #afaeae;">
                                <img src="setup/admin/uploads/<?php echo $row['logo']; ?>" alt="companylogo">
                                <div class="caption text-center">
                                    <h3><?php echo $row['companyname']; ?></h3>
                                    <p><a href="apply-job.php?id=<?php echo $row['id_jobpost']; ?>" class="btn btn-primary btn-flat" role="button">Apply</a>
                                        <hr>
                                    <div class="row">
                                        <div class="col-md-4"><a href="apply-job.php?id=<?php echo $row['id_jobpost']; ?>"><i class="fa fa-briefcase"></i> Apply</a>
                                        </div>
                                        <div class="col-md-4"><a href=""><i class="fa fa-book"></i> Report</a></div>
                                        <div class="col-md-4"><a href=""><i class="fa fa-envelope"></i> Email</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <?php 
      }
    }
    ?>



        </div>
      

      
        <div class="control-sidebar-bg"></div>

    </div>



    <!--====================  footer area ====================-->
    <?php include_once('front_footer.php'); ?>