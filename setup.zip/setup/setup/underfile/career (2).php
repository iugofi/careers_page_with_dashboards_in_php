    <?php 
    error_reporting(E_ERROR | E_PARSE);
    $title = "Iugofi | Best Wifi Mesh System | Dual Band Wifi Router";
$description = "Best wifi mesh system network deals with Iugofi dual band wifi router with advanced features that enhance the reliability and flexibility of your business or home network.";
$keywords = "Iugoifi, Dual-band Wireless Router, Gigabit Ethernet Port Mesh Router, Gigabit Wired Connection, 11AC Dual Frequency Wireless USB Adapter, Mesh Wifi System, Gigabit Router, Gigabit Ethernet Port Mesh Router, Best Dual Band Router, Wireless Dual Band Gigabit Router, How to Use Dual Band Router, Mesh Wifi Extender, Wifi Range Extender, Iugofi Mesh Wifi System, Best Wifi Mesh System, Dual Band Router 5ghz, Dual Band Wifi Router, Gigabit Wifi Router";
include_once('front_header.php');
$countPostCategories = getPostCategoryCount($conn);
//echo $countPostCategories;

?>

<style>
.swiper-pagination {
    position: sticky;

}

.awsm-job-form-inner {
    background: #fff;
    border: 1px solid #dddfe3;
    padding: 35px;
}
.attachment-block {
    border: 1px solid #f4f4f4;
    padding: 5px;
    margin-bottom: 30px;
    background: #f7f7f7;
}
</style>

<div class="site-wrapper-reveal">
    <div class="about-banner-wrap banner-space about-us-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 ml-auto mr-auto">
                    <div class="about-banner-content text-center">
                        <h1 class="mb-15 text-white">Careers</h1>
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="//iugofi.com/">Home</a></li>
                            <li class="breadcrumb-item active">Careers </li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="site-wrapper-reveal">


        <!--===========  feature-large-images-wrapper  Start =============-->
        <div class="feature-large-images-wrapper section-space--ptb_100">
            <div class="container">
                <!-- section-title-wrap Start -->
                <div class="section-title-wrap text-center section-space--mb_60">

                    <h3 class="heading">Career Opportunities</h3>
                    <p>IUGOFI Networking Private Limited. feels proud to provide an equal opportunity for
                        Jobseekers.<br>
                        For Us Our team is our strong asset. We are committed to provide equal employment opportunities
                        to all the applicants.<br>
                        We pride ourselves to be recognized as the best leading online examination solution provider.
                    </p>
                </div>
                <!-- section-title-wrap Start -->



            </div>
        </div>
        <!--===========  feature-large-images-wrapper  End =============-->
        <section class="content-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 latest-job margin-bottom-20">
            <h1 class="text-center">Latest Jobs</h1>            
            <?php 
      
         

        
        //   $sql = "SELECT * FROM job_post Order By Rand() Limit 4";
          $sql = "SELECT * FROM job_post Order By Rand()";
          $result = $conn->query($sql);
          if($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) 
            {
              $sql1 = "SELECT * FROM company WHERE id_company='$row[id_company]'";
              $result1 = $conn->query($sql1);
              if($result1->num_rows > 0) {
                while($row1 = $result1->fetch_assoc()) 
                {
             ?>
            <div class="attachment-block clearfix">
                <div class="row">
                <div class="col-sm-4">
                   <img class="attachment-img" src="setup/admin/uploads/<?php echo $row['job_logo']; ?>" alt="Attachment Image" width="250px" height="200px" class="img-fluid"> 
                </div>
             <div class="col-sm-8">
              <div class="attachment-pushed">
                <h4 class="attachment-heading"><a style="color:#eb7341; margin-top:1em; font-size:39px;" href="view-job-post.php?id=<?php echo $row['id_jobpost']; ?>"><?php echo $row['jobtitle']; ?></a><br> 
                <!--<span class="attachment-heading pull-right">Rs.<?php echo $row['maximumsalary']; ?>/Month</span>-->
                </h4>
                <div class="attachment-text">
                    <div><strong><?php echo $row1['companyname']; ?> | <?php echo $row1['city']; ?> | Experience <?php echo $row['experience']; ?> Years</strong></div>
                </div>
              </div>
             </div>
             </div>
            </div>
          <?php
              }
            }
            }
          }
          ?>

          </div>
        </div>
      </div>
    </section>


        <!--========== Call to Action Area Start ============-->
        <div class="cta-image-area_one section-space--ptb_80 cta-bg-image_two">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-8 col-lg-7">
                        <div class="cta-content md-text-center">
                            <h3 class="heading">Have a <span class="text-color-primary"> Question?</span></h3>

                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <div class="cta-button-group--two text-center">
                            <a href="tel:1-800-810-0886" class="btn btn--white btn-one"><span class="btn-icon mr-2"><i
                                        class="far fa-comment-alt-dots"></i></span> Let's talk</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--========== Call to Action Area End ============-->

    </div>




    <!--====================  footer area ====================-->
    <?php include_once('front_footer.php'); ?>