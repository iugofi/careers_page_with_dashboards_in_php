<?php $title = "Iugofi | Best Wifi Mesh System | Dual Band Wifi Router";
$description = "Best wifi mesh system network deals with Iugofi dual band wifi router with advanced features that enhance the reliability and flexibility of your business or home network.";
$keywords = "Iugoifi, Dual-band Wireless Router, Gigabit Ethernet Port Mesh Router, Gigabit Wired Connection, 11AC Dual Frequency Wireless USB Adapter, Mesh Wifi System, Gigabit Router, Gigabit Ethernet Port Mesh Router, Best Dual Band Router, Wireless Dual Band Gigabit Router, How to Use Dual Band Router, Mesh Wifi Extender, Wifi Range Extender, Iugofi Mesh Wifi System, Best Wifi Mesh System, Dual Band Router 5ghz, Dual Band Wifi Router, Gigabit Wifi Router";
include_once('front_header.php');
$countPostCategories = getPostCategoryCount($conn);
//echo $countPostCategories;
$c_id = $_GET['id'];
?>

<style>
.swiper-pagination {
    position: sticky;

}
</style>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Function to sanitize input data
    function sanitize_input($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    // Retrieve form data
    $applicant_name = sanitize_input($_POST['awsm_applicant_name']);
    $applicant_email = sanitize_input($_POST['awsm_applicant_email']);
    $applicant_phone = sanitize_input($_POST['awsm_applicant_phone']);
    $applicant_letter = sanitize_input($_POST['awsm_applicant_letter']);
    $job_id = sanitize_input($_POST['awsm_job_id']);

    // Validate form data
    $errors = [];

    if (empty($applicant_name)) {
        $errors['awsm_applicant_name'] = 'Full Name is required';
    }

    if (empty($applicant_email) || !filter_var($applicant_email, FILTER_VALIDATE_EMAIL)) {
        $errors['awsm_applicant_email'] = 'Please enter a valid email address';
    }

    if (empty($applicant_phone)) {
        $errors['awsm_applicant_phone'] = 'Phone is required';
    }

    if (empty($applicant_letter)) {
        $errors['awsm_applicant_letter'] = 'Cover Letter is required';
    }

    if (empty($_FILES['awsm_file']['name'])) {
        $errors['awsm_file'] = 'CV/Resume is required';
    }

    // If there are no validation errors, proceed to save data to the database
    if (empty($errors)) {
        // Additional file upload handling can be implemented here
        $upload_directory = 'uploads/';  // Set your upload directory
        $uploaded_file = $upload_directory . basename($_FILES['awsm_file']['name']);

        // Check if the file has been uploaded successfully
        if (move_uploaded_file($_FILES['awsm_file']['tmp_name'], $uploaded_file)) {
            // Insert data into the database
            // Replace the placeholders with your actual database table and column names
            $sql = "INSERT INTO candidate_application (applicant_name, applicant_email, applicant_phone, applicant_letter, job_id, cv_resume_path) 
                    VALUES ('$applicant_name', '$applicant_email', '$applicant_phone', '$applicant_letter', '$job_id', '$uploaded_file')";

            // Execute the query
            $result = mysqli_query($conn, $sql);

            if ($result) {
    // Redirect to success.php
    header("Location: success.php");
    exit(); // Ensure that no further code is executed after the redirect
} else {
    echo "Error: " . mysqli_error($conn);
}
        } else {
            echo "Error uploading file.";
        }
    } else {
        // Output validation errors
        // echo "Validation errors: " . json_encode($errors);
    }
}
?>


<section class="mt-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 p-5 mb-5" style=" border: 1px solid #33333329; box-shadow: 3px 0px 20px 3px #dfc9c940;" >
                <div class="awsm-job-form-inner  mb-5">
                    <!--<h2>-->
                    <!--    Apply for this position </h2>-->
                    <form id="awsm-application-form" class="awsm-application-form" name="applicationform" method="post"
                        enctype="multipart/form-data" novalidate="novalidate">

                        <div class="form-group">
                            <label for="awsm-applicant-name">Full Name <span
                                    class="awsm-job-form-error">*</span></label>
                            <input type="text" name="awsm_applicant_name" class="form-control" id="awsm-applicant-name"
                                required="" data-msg-required="This field is required.">
                        </div>
                        <div class="form-group">
                            <label for="awsm-applicant-email">Email <span
                                    class="awsm-job-form-error">*</span></label><input type="email"
                                name="awsm_applicant_email" class="form-control" id="awsm-applicant-email" required=""
                                data-msg-required="This field is required." data-rule-email="true"
                                data-msg-email="Please enter a valid email address.">
                        </div>
                        <div class="form-group"><label for="awsm-applicant-phone">Phone <span
                                    class="awsm-job-form-error">*</span></label><input type="tel"
                                name="awsm_applicant_phone" class="form-control" id="awsm-applicant-phone" required=""
                                data-msg-required="This field is required."></div>
                        <div class="form-group"><label for="awsm-cover-letter">Cover Letter <span
                                    class="awsm-job-form-error">*</span></label><textarea name="awsm_applicant_letter"
                                class="form-control" id="awsm-cover-letter" required=""
                                data-msg-required="This field is required." rows="5" cols="50"></textarea></div>
                        <div class="form-group"><label for="awsm-application-file">Upload CV/Resume
                                <span class="awsm-job-form-error">*</span></label>
                            <input type="file" name="awsm_file"
                                class="form-control" id="awsm-application-file" required=""
                                data-msg-required="This field is required." accept=".pdf, .doc, .docx">
                                
                                <small>Allowed
                                Type(s): .pdf, .doc, .docx</small>
                        </div>
                        <div class="form-group awsm-job-inline-group"><input name="awsm_form_privacy_policy"
                                class="awsm-job-form-field" id="awsm_form_privacy_policy" value="yes" type="checkbox"
                                data-msg-required="This field is required." aria-required="true" required=""><label
                                for="awsm_form_privacy_policy">By using this form you agree
                                with the storage and handling of your data by this website. <span
                                    class="awsm-job-form-error">*</span></label></div>
                        <input type="hidden" name="awsm_job_id" value="<?php echo $c_id ?>">

                        <div class="form-group">
                            <input type="submit" name="form_sub" id="awsm-application-submit-btn"
                                class="btn btn-fill-out btn-block" value="Submit" data-response-text="Submitting..">
                        </div>

                    </form>

                    <div class="awsm-application-message" style="display: none;"></div>


                </div>
            </div>
        </div>
    </div>
</section>







<!--====================  footer area ====================-->
<?php include_once('front_footer.php'); ?>