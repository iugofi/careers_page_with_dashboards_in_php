<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
//Code for Submit 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $companyname = $_POST["companyname"];
    $country = $_POST["country"];
    $state = $_POST["state"];
    $city = $_POST["city"];
    $contactno = $_POST["contactno"];
    $website = $_POST["website"];
    $email = $_POST["email"];
    $aboutme = $_POST["aboutme"];
   // Check if "logo" file is uploaded
   if(isset($_FILES["logo"]) && $_FILES["logo"]["error"] == 0) {
    $logo = $_FILES["logo"]["name"];
    $uploadFolder = "uploads/";
    $uploadFilePath = $uploadFolder . basename($_FILES["logo"]["name"]);

    // Move uploaded file to a folder
    move_uploaded_file($_FILES["logo"]["tmp_name"], $uploadFilePath);
} else {
    // Handle the case where the logo file is not uploaded
    $logo = "";
}

    $createdAt = $_POST["createdAt"];
    $active = $_POST["active"];

    // Move uploaded file to a folder (you need to create this folder)
    $uploadFolder = "admin/uploads/";
    $uploadFilePath = $uploadFolder . basename($_FILES["logo"]["name"]);
    move_uploaded_file($_FILES["logo"]["tmp_name"], $uploadFilePath);

    // Prepare and execute the SQL query
    $sql = "INSERT INTO company (name, companyname, country, state, city, contactno, website, email, aboutme, logo, createdAt, active) 
            VALUES ('$name', '$companyname', '$country', '$state', '$city', '$contactno', '$website', '$email', '$aboutme', '$logo', '$createdAt', '$active')";

    if ($con->query($sql) === TRUE) {
        echo "<script>alert('Company updated successfully');</script>";
       echo "<script type='text/javascript'> document.location = 'manage-company.php'; </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
    $con->close();
}



    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Add Company</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="../css/styles.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous">
    </script>
</head>

<body class="sb-nav-fixed">
    <?php include_once('includes/navbar.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">

                <h1 class="mt-4">Add Company Profile</h1>
                   
                    <div class="card mb-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Name</th>
                                        <td><input class="form-control" id="name" name="name" type="text"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>Company Name</th>
                                        <td><input class="form-control" id="companyname" name="companyname" type="text"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>Country</th>
                                        <td><input class="form-control" id="country" name="country" type="text"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>State</th>
                                        <td><input class="form-control" id="state" name="state" type="text"
                                                 required /></td>
                                    </tr>

                                    <tr>
                                        <th>City</th>
                                        <td><input class="form-control" id="city" name="city" type="text"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>Contact No.</th>
                                        <td colspan="3"><input class="form-control" id="contactno" name="contactno"
                                                type="text" 
                                                pattern="[0-9]{10}" title="10 numeric characters only" maxlength="10"
                                                required /></td>
                                    </tr>
                                    <tr>
                                        <th>Website</th>
                                        <td><input class="form-control" id="website" name="website" type="text"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><input class="form-control" id="email" name="email" type="email"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>Aboutme</th>
                                        <td><input class="form-control" id="aboutme" name="aboutme" type="text"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <th>Logo</th>
                                        <td><input class="form-control" id="logo" name="logo" type="file"
                                                 required /></td>
                                    </tr>  
                                    <tr>
                                        <th>Post Date</th>
                                        <td><input class="form-control" id="createdAt" name="createdAt" type="datetime-local"
                                                 required /></td>
                                    </tr>              
                                    <tr>
                                        <th>Active</th>
                                        <td><input class="form-control" id="active" name="active" type="number"
                                                 required /></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" style="text-align:center ;"><button type="submit"
                                                class="btn btn-primary btn-block" name="Submit">Company Registered</button></td>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                   

                </div>
            </main>
            <?php include('../includes/footer.php');?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="../js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="../js/datatables-simple-demo.js"></script>
</body>

</html>
<?php } ?>