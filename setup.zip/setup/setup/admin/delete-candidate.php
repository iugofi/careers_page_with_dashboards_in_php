<?php
include_once('../includes/config.php');


if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare the SQL query
    $sql = "DELETE FROM candidate_application WHERE id = $id";

    // Execute the query and handle errors
    if ($con->query($sql) === TRUE) {
        $response = array('success' => true);
        echo json_encode($response);
    } else {
        $response = array('success' => false, 'message' => 'Error deleting record: ' . $conn->error);
        echo json_encode($response);
    }

    // Close the database connection
    $con->close();
} else {
    $response = array('success' => false, 'message' => 'Invalid parameters');
    echo json_encode($response);
}
?>
