<?php
session_start();
include_once('../includes/config.php');

if (strlen($_SESSION['adminid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_GET['id'])) {
        $candidateId = intval($_GET['id']);

        // Use prepared statements to prevent SQL injection
        $deleteQuery = $con->prepare("DELETE FROM job_post WHERE id_jobpost = ?");
        $deleteQuery->bind_param("i", $candidateId);

        if ($deleteQuery->execute()) {
            // Successful deletion
            $deleteQuery->close();
            $con->close();

            // Redirect to the manage job post page
            header("Location: manage-job-post.php");
            exit();
        } else {
            // Handle deletion error, you might want to log or display an error message
            echo "Error deleting record: " . $deleteQuery->error;
        }
    } else {
        echo "Invalid request";
    }
}
?>
