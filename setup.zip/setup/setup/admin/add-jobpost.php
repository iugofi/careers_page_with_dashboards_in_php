<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
//Code for Submit 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $jobtitle=$_POST['jobtitle'];
    $description=$_POST['description1'];
    $minimumsalary=$_POST['minimumsalary'];
    $maximumsalary=$_POST['maximumsalary'];
    $experience=$_POST['experience'];
    $qualification=$_POST['qualification'];
    $id_company=$_POST['id_company'];
    $createdat=$_POST['createdat'];

    // Check if "logo" file is uploaded
   if(isset($_FILES["job_logo"]) && $_FILES["job_logo"]["error"] == 0) {
    $logo = $_FILES["job_logo"]["name"];
    $uploadFolder = "uploads/";
    $uploadFilePath = $uploadFolder . basename($_FILES["job_logo"]["name"]);

    // Move uploaded file to a folder
    move_uploaded_file($_FILES["job_logo"]["tmp_name"], $uploadFilePath);
} else {
    // Handle the case where the logo file is not uploaded
    $logo = "";
}

// Move uploaded file to a folder (you need to create this folder)
$uploadFolder = "admin/uploads/";
$uploadFilePath = $uploadFolder . basename($_FILES["job_logo"]["name"]);
move_uploaded_file($_FILES["job_logo"]["tmp_name"], $uploadFilePath);

    // Prepare and execute the SQL query
    $sql = "INSERT INTO job_post (jobtitle, description, minimumsalary, maximumsalary, experience, qualification, id_company, createdat, job_logo) 
            VALUES ('$jobtitle', '$description', '$minimumsalary', '$maximumsalary', '$experience', '$qualification', '$id_company', '$createdat','$logo')";

    if ($con->query($sql) === TRUE) {
        echo "<script>alert('Job Post Add successfully');</script>";
       echo "<script type='text/javascript'> document.location = 'manage-job-post.php'; </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
    $con->close();
}



    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Add Job Post</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="../css/styles.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous">
    </script>
    <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
    <style>
    .button {
        background-color: #155DE9;
        color: white;
        border: none;
        padding: 10px 20px;
        text-align: center;
        font-family: 'Arial';
    }
    </style>
    <script type="text/javascript">
    window.onload = () => {
        CKEDITOR.replace("description1");
    };

    function sendText() {
        window.parent.postMessage(CKEDITOR.instances.CK1.getData(), "*");
    }
    </script>
</head>

<body class="sb-nav-fixed">
    <?php include_once('includes/navbar.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">

                    <h1 class="mt-4">Add job Post Profile</h1>

                    <div class="card mb-4">
                        <form method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>job Title</th>
                                        <td><input class="form-control" id="jobtitle" name="jobtitle" type="text"
                                                required /></td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td>
                                            <textarea id="CK1" name="description1" required>
                                            </textarea>                                           
                                            <br>
                                            <!--<button class="button" onclick="sendText()">Submit text</button>-->
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Minimumsalary</th>
                                        <td><input class="form-control" id="minimumsalary" name="minimumsalary"
                                                type="number" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Maximumsalary</th>
                                        <td><input class="form-control" id="maximumsalary" name="maximumsalary"
                                                type="number" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Experience</th>
                                        <td><input class="form-control" id="experience" name="experience" type="text"
                                                required />
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Qualification</th>
                                        <td><input class="form-control" id="qualification" name="qualification"
                                                type="text" required />
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Post Date</th>
                                        <td><input class="form-control" id="createdat" name="createdat"
                                                type="datetime-local" required /></td>
                                    </tr>
                                    <tr>
                                        <th>Job Logo</th>
                                        <td><input class="form-control" id="job_logo" name="job_logo" type="file"
                                                required /></td>
                                    </tr>
                                    <tr>
                                        <th>Company Name</th>
                                        <td>
                                            <select class="form-control" id="id_company" name="id_company" required>
                                                <?php
                                                // Assuming $conn is your database connection
                                                $query = "SELECT * FROM company";
                                                $resultnew = mysqli_query($con, $query);

                                                while ($row = mysqli_fetch_assoc($resultnew)) {
                                                    echo '<option value="' . $row['id_company'] . '" ' . $selected . '>' . $row['companyname'] . '</option>';
                                                }

                                                // Don't forget to close the database connection after use
                                                mysqli_close($con);
                                                ?>
                                            </select>
                                        </td>
                                    </tr>


                                    <tr>
                                        <td colspan="4" style="text-align:center ;"><button type="submit"
                                                class="btn btn-primary btn-block" name="Submit">Add Job Post</button>
                                        </td>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>


                </div>
            </main>
            <?php include('../includes/footer.php');?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
    <script src="../js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="../js/datatables-simple-demo.js"></script>
</body>

</html>
<?php } ?>