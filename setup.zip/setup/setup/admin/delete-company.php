<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
// for deleting user
if(isset($_GET['id']))
{
$adminid=$_GET['id'];
$msg=mysqli_query($con,"delete from cusers where id='$adminid'");
if($msg)
{
echo "<script>alert('Data deleted');</script>";
}
}

if (isset($_GET['id'])) {
    // Sanitize the candidate ID (assuming it's an integer)
    $candidateId = intval($_GET['id']);

    // Perform the deletion logic
    $deleteQuery = "DELETE FROM company WHERE id_company = $candidateId";

    if ($con->query($deleteQuery) === TRUE) {
        header("Location: manage-company.php");
        echo "<script>alert('Company Data deleted');</script>";
        exit();
    } else {
        // Handle deletion error, you might want to log or display an error message
        echo "Error deleting record: " . $con->error;
    }
    $con->close();
} else {

    echo "Invalid request";
}
?>


<?php } ?>